package com.feicuiedu.news.servlet;

import com.feicuiedu.utils.DBUtil;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Created by Administrator on 2017/4/27.
 */
public class SrvMaintain extends javax.servlet.http.HttpServlet {
	protected void doPost(javax.servlet.http.HttpServletRequest request,
						  javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
		
		
		
	}
	
	protected void doGet(javax.servlet.http.HttpServletRequest request,
						 javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {
		
	}
}
